# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['brain_games']
install_requires = \
['prompt>=0.4.1,<0.5.0']

setup_kwargs = {
    'name': 'brain-games',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'zenvener',
    'author_email': 'zenxiontrue@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
